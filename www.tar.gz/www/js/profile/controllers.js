(function (angular) {

	'use strict';
	angular.module('api.profile.controllers', [])
	.controller('ProfileCtrl', controller);
	function controller($scope, ProfileService, $window, $state){
		var vm = this;
		vm.data ={};
		try{
			vm.data.userInfo = JSON.parse($window.localStorage.getItem('userInfo'));
		}catch(err){

		}

		if(!vm.data.userInfo){
			$state.go("login");
		}
		if(vm.data.userInfo){
			ProfileService.orders(vm.data.userInfo).then(function(result) {
			vm.data.orders = result.data;
		})
		}
		

	}

})(window.angular);