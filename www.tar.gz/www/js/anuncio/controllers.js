(function (angular) {

  'use strict';

  angular.module('api.anuncio.controllers', ['starter.services'])


  .controller('AnuncioCtrl',controller);

  function controller($scope, $stateParams,PlaylistsServices, $ionicPopup,$state, $sce, $timeout, LOCALSTORAGE){
    
    var user = JSON.parse(localStorage.getItem(LOCALSTORAGE.key));
    if(!user){
      $state.go('login');
    }

    var vm = this;
    vm.data = {};
    vm.videoSource ="";
    var updateN = 5000;
    var timer;

    PlaylistsServices.anuncio($stateParams.bannerId).then(function(result) {

      if(result !="null"){
        vm.data= result;
        vm.data.username =user.username;
        vm.data.serialCelPhone = "1234";
        if(vm.data.imageURL.indexOf("youtube") > 0){
          vm.videoSource = $sce.trustAsResourceUrl("http://thenewcode.com/assets/videos/polina.webm");
          vm.data.imageURL = "";
        }

      //$scope.videoSource = $sce.trustAsResourceUrl("http://thenewcode.com/assets/videos/polina.webm");
      timer = $timeout(function () {
        callAtTimeout();
      }, updateN);


    }else{
      $state.go('app.playlists');
    }

  }, function(errMsg) {
    var alertPopup = $ionicPopup.alert({
      title: 'Error!',
      template: errMsg
    });
    $state.go('app.playlists');
  });

    function callAtTimeout(){
  
      PlaylistsServices.contClick(vm.data).then(function(result) {
        console.log("Cont click");
      });
    }

    $scope.$on('$ionicView.beforeLeave', function() {
      $timeout.cancel(timer);
        //alert("");
      });
  }

})(window.angular);





