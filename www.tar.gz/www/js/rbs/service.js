(function(angular) {
 'use strict';
 
 angular
       .module('api.rbs.service',[]) // Define a qual módulo seu .service pertence
       .factory('RBSService', RBSService); //Define o nome a função do seu .service

       function RBSService($q, $http,API_URL) {

        var vm = this;
        vm.service ={
         rbsBanners   : rbsBanners,
         rbs          : rbs,
         advertisings : advertisings
       };
       return vm.service;


       function rbsBanners() {
        var def = $q.defer();
        $http.get(API_URL.url + '/banners?filter=[{"title":"wifi"}]')
        .then(function(res){ 
          def.resolve(res.data["banners"][0]);

        })

        return def.promise;
      };

      function rbs() {
        var def = $q.defer();
        $http.get(API_URL.url + '/rbs')
        .then(function(res){ 
          def.resolve(res.data['rbs']);

        })

        return def.promise;
      };

      function advertisings() {
        var def = $q.defer();
        $http.get(API_URL.url + '/advertisings')
        .then(function(res){ 
          def.resolve(res.data);

        })

        return def.promise;
      };

    }
  })(window.angular);


