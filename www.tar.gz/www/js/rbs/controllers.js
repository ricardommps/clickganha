(function (angular) {

	'use strict';
	angular.module('api.rbs.controllers', [])
	.controller('RBSCtrl', controller);
	function controller($scope, RBSService, $cordovaGeolocation){
		var vm = this;
		vm.data ={};
		
		RBSService.rbsBanners().then(function(result) {
			vm.data.banner = result.data;
		})

		var latLng = new google.maps.LatLng(-15.4968874,-56.5820345);	    
		var mapOptions = {center: latLng,zoom: 3,  mapTypeId: google.maps.MapTypeId.ROADMAP};	    
		var map = new google.maps.Map(document.getElementById("map"), mapOptions);

		RBSService.rbs().then(function(result) {
			var data = result.data;
			for(var i in data){
				latLng = new google.maps.LatLng({'lat': parseFloat(data[i].circle.center.lat), 'lng': parseFloat(data[i].circle.center.lng)}); 
				var marker = new google.maps.Marker({
					position: latLng,
					map: map,
					icon: "img/wifi.png",
					title: 'Erb'
				});

				new google.maps.Circle({
					strokeColor: '#3865A3',
					strokeOpacity: 0.8,
					strokeWeight: 1,
					fillColor: '#5eb346',
					fillOpacity: 0.35,
					map: map,
					radius: 11111,
				});
			}
			vm.data.map = map;
		})

		RBSService.rbs().then(function(result) {
			var data = result.data;
			for(i in data){
				vm.data.advertisings.push({

					'title' : data[i].title,
					'banner' : data[i].banner,
					'description' : data[i].description,

				});
			}
		});

	}

})(window.angular);