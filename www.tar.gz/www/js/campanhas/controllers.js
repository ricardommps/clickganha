(function (angular) {

  'use strict';
  
  angular.module('api.campanhas.controllers', ['starter.services'])

  .controller('CampanhasCtrl', controller);
  
  function controller($scope, $stateParams, $http, PlaylistsServices, $state, LOCALSTORAGE){

    var user = JSON.parse(localStorage.getItem(LOCALSTORAGE.key));
    if(!user){
      $state.go('login');
    }

    var vm = this;
    vm.data = {};
    PlaylistsServices.banners().then(function(result) {
      vm.data = result;

      PlaylistsServices.credits(user).then(function(resultsCredits) {
        console.log("credits");
        console.log(resultsCredits);
        angular.forEach(vm.data, function(value, key){
          angular.forEach(resultsCredits.credits, function(valueCredtis, keyCredtis){
           if(value.bannerId == valueCredtis.bannerId){
            value.clickCont = valueCredtis.clickCont;         
          }; 
        });
        });
      });

    })
  }
})(window.angular);


