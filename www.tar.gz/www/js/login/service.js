(function(angular) {
 'use strict';
 
 angular
       .module('api.login.service',[]) // Define a qual módulo seu .service pertence
       .factory('LoginsService', LoginsService); //Define o nome a função do seu .service

       function LoginsService($q, $http, AUTH_API_URL, API_ENDPOINT) {

         var vm = this;
         vm.service ={
           creatUser      : creatUser,
           resetPassword  : resetPassword,
           signin         : signin
         };
         return vm.service

         vm.data ={};

         function creatUser(data) {
          var def = $q.defer();
          $http.post(API_ENDPOINT.url + '/creatUser',data)
          .success(function(data){
            def.resolve(data);
          })
          .error(function(){
            def.reject("Failed to crear user");
          });

          return def.promise;
        }


        function resetPassword(){

        }

        function signin(data) {
          var def = $q.defer();
          var user = 'email='+data.form.email+'&password='+data.form.password;
          console.log(user);
          $http.post(AUTH_API_URL.url + '/signin',user,{
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          })
          .then(function(res){ 
            console.log(res);
            def.resolve(res.data);

          },function(data) {
             def.reject("Failed login");
          })
          
          return def.promise;
        }

      }
    })(window.angular);


