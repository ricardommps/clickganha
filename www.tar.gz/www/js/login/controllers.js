(function (angular) {

	'use strict';
	angular.module('api.login.controllers', ['starter.services', 'ionMdInput'])
	.controller('LoginCtrl', controller);
	function controller($scope,$state, LOCALSTORAGE, LoginsService, $window, $ionicLoading, $ionicModal){
		var vm = this;
		$scope.modal = {};
		vm.data ={};
		vm.signin = signin;
		vm.data.loginForm=true;

		try{
			var user = JSON.parse($window.localStorage.getItem('userInfo'));
			if(user.email.length > 0 && user.password.length > 0){
				$state.go('app.home');
			}
			
		}catch(err){

		}
		console.log(JSON.parse($window.localStorage.getItem('userInfo')));


		$ionicModal.fromTemplateUrl('templates/modal.html', {
			scope: $scope
		}).then(function(modal) {
			$scope.modal.login_fail = modal;	   
		});	
		
		function login(user){
			loading();
			LoginsService.signin(user)
			.then(function(res) {
				console.log(res);
				try{
					var userInfo = res.user;
					$window.localStorage.setItem('userInfo', JSON.stringify(userInfo));
				//$window.localStorage.setItem('userInfo', JSON.stringify(userInfo));
				vm.data.userInfo = JSON.parse($window.localStorage.getItem('userInfo'));
				$state.go('app.home');
				$ionicLoading.hide();
			}catch(err){
				$scope.modal.login_fail.show();
				$scope.message_modal="Não foi possivel realizar o login.";
				$ionicLoading.hide();
			}	

		},function(data) {
			$scope.modal.login_fail.show();
			$scope.message_modal="Não foi possivel realizar o login.";
			$ionicLoading.hide();
		})
		}

		function signin(form){
			login(vm.data);
		}

		function loading(){

			$ionicLoading.show({
				content: 'Loading',
				animation: 'fade-in',
				showBackdrop: true,
				maxWidth: 200,
				showDelay: 0
			});

		}

	}

})(window.angular);