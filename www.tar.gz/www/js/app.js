  // Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic',
  'ngCordova',
  'api.login.controllers',
  'api.login.router',
  'api.login.service',
  'api.menu.router',
  'api.menu.controllers',
  'api.home.controllers',
  'api.home.router',
  'api.home.service',
  'api.secure.controllers',
  'api.secure.router',
  'api.anuncio.controllers',
  'api.anuncio.router',
  'api.campanhas.controllers',
  'api.campanhas.router',
  'api.configuracoes.controllers',
  'api.configuracoes.router',
  'api.configuracoes.service',
  'api.posts.controllers',
  'api.posts.service',
  'api.posts.router',
  'api.post.controllers',
  'api.post.service',
  'api.post.router',
  'api.profile.controllers',
  'api.profile.service',
  'api.profile.router',
  'api.faq.controllers',
  'api.faq.service',
  'api.faq.router',
  'api.rbs.controllers',
  'api.rbs.service',
  'api.rbs.router',
  'api.promotions.controllers',
  'api.promotions.service',
  'api.promotions.router',
  'api.promotion.controllersPromotion',
  'api.promotion.controllersCategory',
  'api.promotion.service',
  'api.promotion.router',
  'starter.constants'])

.run(function($ionicPlatform, $rootScope, $timeout) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
    window.cordova.plugins.notification.local.onadd = function(id, state, json){
      var notification = {
        id: id,
        state: state,
        json : json
      }

      $timeout(function () {
        $rootScope.$broadcast('$cordovaLocalNotification:added', notification);
      });
    }
  });
})

.config(['$httpProvider', function($httpProvider) {

        $httpProvider.defaults.useXDomain = true;
        delete $httpProvider.defaults.headers.common['X-Requested-With'];  
    }
])
