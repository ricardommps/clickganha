(function (angular) {

	'use strict';
	angular.module('api.promotion.controllersCategory', [])
	.controller('PromotionCategoryCtrl', controller);

	function controller($scope, PromotionService){
		var vm = this;
		vm.data ={};
		PromotionsService.banner().then(function(result) {
			vm.data.banner = result.data;

		})

		PromotionsService.promotionCategory().then(function(result) {
			var categories = result.data;
			for(var i in categories){
				vm.data.promotionCategories.push({
					'_id': categories[i]._id,
					'name': categories[i].name,
					'image': categories[i].image
				});
			}
		})
	}

})(window.angular);