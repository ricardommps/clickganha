(function (angular) {

	'use strict';
	angular.module('api.promotion.controllersPromotion', [])
	.controller('PromotionCtrl', controller)
	function controller($scope, PromotionService){
		var vm = this;
		vm.data ={};
		
		PromotionsService.promotion().then(function(result) {
			vm.data.promotion = result.data;
		})
	}

})(window.angular);