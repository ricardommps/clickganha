(function(angular) {
 'use strict';
 
 angular
       .module('api.promotion.service',[]) // Define a qual módulo seu .service pertence
       .factory('PromotionService', PromotionService); //Define o nome a função do seu .service

       function PromotionService($q, $http,API_URL,$stateParams) {

         var vm = this;
         vm.service ={
           promotion          : promotion,
           promotionCategory  : promotionCategory,
           banner             : banner
         };
         return vm.service;


         function promotion() {
          var def = $q.defer();
          $http.get(API_URL.url + '/promotions/'+$stateParams.promotionId)
          .then(function(res){ 
            def.resolve(res.data['promotion']);

          })
          
          return def.promise;
        }

        function promotionCategory() {
          var def = $q.defer();
          $http.get(API_URL.url + '/promotion-categories')
          .then(function(res){ 
            def.resolve(res.data['promotion-categories']);

          })
          
          return def.promise;
        }

        function banner() {
          var def = $q.defer();
          $http.get(API_URL.url + '/banners?filter=[{"title":"promotion"}]')
          .then(function(res){ 
            def.resolve(res.data["banners"][0]);

          })
          
          return def.promise;
        }

      }
    })(window.angular);


