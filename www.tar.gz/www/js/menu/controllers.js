(function (angular) {

	'use strict';
	angular.module('api.menu.controllers', ['starter.services'])


	.controller('MenuCtrl',controller);

	function controller($scope, PlaylistsServices, $state, LOCALSTORAGE){
		var user = JSON.parse(localStorage.getItem(LOCALSTORAGE.key));
		if(!user){
			$state.go('login');
		}
		
		var vm = this;
		vm.data = user;
		vm.logout = logout;

		function logout(){
			localStorage.removeItem(LOCALSTORAGE.key);
			$state.go('login');
		}	
	}
	
})(window.angular);
