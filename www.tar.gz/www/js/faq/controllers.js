(function (angular) {

	'use strict';
	angular.module('api.faq.controllers', [])
	.controller('FaqCtrl', controller);
	function controller($scope, FaqService){
		var vm = this;
		vm.data ={};
		vm.shownFaq;
		vm.toggleFaq = toggleFaq;
		vm.isFaqShown = isFaqShown;

		FaqService.faqCategories().then(function(res) {
			vm.data.banner = res;
		})

		FaqService.faqs().then(function(res) {
			vm.data.faqs = res;
		})

		function toggleFaq(faq){
			if(vm.isFaqShown(faq)){
				$scope.shownFaq = null;
			} else {
				$scope.shownFaq = faq;
			}
		}

		function isFaqShown(faq){
			return $scope.shownFaq === faq;
		}
	}

})(window.angular);