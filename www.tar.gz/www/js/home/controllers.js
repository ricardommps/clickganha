(function (angular) {

	'use strict';
	angular.module('api.home.controllers', ['starter.services'])


	.controller('HomerCtrl',controller);

	function controller($scope, PlaylistsServices, $state, LOCALSTORAGE, PromotionService, HomeService, $ionicSlideBoxDelegate, $ionicSideMenuDelegate){
		console.log("HomerCtrl");
		console.log(LOCALSTORAGE.key);
		try{
		    vm.data.userInfo=JSON.parse(localStorage.getItem(LOCALSTORAGE.key));
		    vm.data.userInfo.email;
		}catch(err)
		{
		    ///$state.go("login");
		}
		
		var vm = this;
		vm.data = {};
		vm.previous = previous;
		vm.slideChanged = slideChanged;


		HomeService.sections().then(function(res) {
			console.log('sections');
			console.log(res);
			vm.data.first_section=res["sections"][1];
			vm.data.second_section=res["sections"][0];
		});


		HomeService.posts().then(function(res) {
			vm.data.posts=res.slice(0,3);
		});

		HomeService.home().then(function(res) {
			vm.data.banners=res;
		});

		$ionicSlideBoxDelegate.next();
		//$ionicSideMenuDelegate.canDragContent(false);


		function previous(){
			$ionicSlideBoxDelegate.previous();
		}

		function slideChanged(index){
			vm.data.slideIndex = index;
		}

		PromotionService.promotionCategory().then(function(res) {
			console.log("promotionCategory");
			console.log(res);
			vm.data.promotionCategories = res.slice(0,6);
		})


		/*
		
		PlaylistsServices.banners().then(function(result) {
			vm.data = result[0];
			totalCredits();
		});

		function totalCredits(){

			var credits = 0;
			
			PlaylistsServices.credits(user).then(function(resultsCredits) {

				angular.forEach(resultsCredits.credits, function(valueCredtis, keyCredtis){
					credits = parseInt(valueCredtis.clickCont, 10) + credits;
				});
				vm.data.totalCredits = credits;
			});

		}
		*/
		
	}

})(window.angular);
