(function (angular) {

	'use strict';
	angular.module('api.checkout.controllers', [])
	.controller('CheckoutCtrl', controllerCheckout)
	.controller('CheckoutSuccessCtrl', controllerSuccess)
	.controller('CheckoutErrorCtrl', controllerError);

	function controllerSuccess(){

	}

	function controllerError(){
		
	}

	function controllerCheckout($scope, PromotionService, CheckoutService, $timeout, $state, $window){
		var vm = this;
		vm.data ={};
		vm.verifyTransaction 	= verifyTransaction;
		vm.pay 					= pay;
		
		PromotionService.promotion().then(function(res) {
			vm.data.promotion = res.data;
		});

		function verifyTransaction(w,code){
			CheckoutService.transaction(code).then(function(res) {
				var data = res.data;
				if(data){
					w.close();
					$state.go('app.profile')
				}else{
					$timeout(function(){
						vm.verifyTransaction(w,code);
					},2000);
				}


			}
		}

		function pay(){
			vm.data.userInfo = JSON.parse($window.localStorage.getItem('userInfo'));
			var paymentInternalToken = Math.floor((Math.random() * 9999999999) );
	    
		    var data = {
			id 				: vm.data.promotion._id,
			price 			: vm.data.promotion.price,
			description 	: vm.data.promotion.description,
			buyer_name 		: vm.data.userInfo.name,
			buyer_email 	: vm.data.userInfo.email,
			code			:paymentInternalToken
		    };

		    CheckoutService.pay(data).then(function(res) {
		    	var url = "https://sandbox.pagseguro.uol.com.br/v2/checkout/payment.html?code="+res.data;
		    	window_payment=window.open(url, '_blank','location=no');
		   		vm.verifyTransaction(window_payment,paymentInternalToken);
		    });
		}
	}

})(window.angular);