(function(angular) {
 'use strict';
 
 angular
       .module('api.promotions.service',[]) // Define a qual módulo seu .service pertence
       .factory('PromotionsService', PromotionsService); //Define o nome a função do seu .service

       function PromotionsService($q, $http,API_URL,$stateParams) {

         var vm = this;
         vm.service ={
           promotions  : promotions
         };
         return vm.service;


         function promotions() {
          var def = $q.defer();
          $http.get(API_URL.url + '/promotions/?filters=[{"category":"'+$stateParams.categoryId+'"}]})')
          .then(function(res){ 
            def.resolve(res.data['promotions']);

          })
          
          return def.promise;
        }

      }
    })(window.angular);


