(function (angular) {

	'use strict';
	angular.module('api.promotions.controllers', [])
	.controller('PromotionsCtrl', controller);
	function controller($scope, PromotionsService){
		var vm = this;
		vm.data ={};
		
		PromotionsService.promotions().then(function(result) {
			vm.data.promotions = result.data;
		})
	}

})(window.angular);