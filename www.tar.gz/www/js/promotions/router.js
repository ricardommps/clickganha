(function (angular) {

  'use strict';
  angular.module('api.promotions.router', [])
  .config(config);
  function config($stateProvider) {
    $stateProvider
    .state('app.promotions', {
      url: '/promotions/:categoryId',
      views: {
        'menuContent': {
          templateUrl: 'js/promotions/promotions.html',
          controller: 'PromotionsCtrl as vm'
        }
      }
    });
  }
  

})(window.angular);


